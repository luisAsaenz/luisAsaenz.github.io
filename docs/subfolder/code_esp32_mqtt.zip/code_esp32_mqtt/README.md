# ESP32 MQTT / UART support code

This code is shared as part of the Embedded Systems Design course at Arizona State University.
testing where this push goes

Various parts of the code have been derived from the following:

* <https://github.com/peterhinch/micropython-async/blob/master/v3/as_demos/auart.py>
* <https://github.com/tve/mqboard/blob/master/mqtt_async/hello-world.py>
* <https://github.com/peterhinch/micropython-mqtt>
* <https://github.com/embedded-systems-design/external_pycopy-lib>
